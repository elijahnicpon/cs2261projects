void goDeathEnergy();
void doDeathEnergy();