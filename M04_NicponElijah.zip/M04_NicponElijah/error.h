// error sound made by wav2c

extern const unsigned int error_sampleRate;
extern const unsigned int error_length;
extern const signed char error_data[];
