// sixth_station sound made by wav2c

extern const unsigned int sixth_station_sampleRate;
extern const unsigned int sixth_station_length;
extern const signed char sixth_station_data[];
