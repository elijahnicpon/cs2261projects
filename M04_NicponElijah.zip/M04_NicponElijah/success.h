// success sound made by wav2c

extern const unsigned int success_sampleRate;
extern const unsigned int success_length;
extern const signed char success_data[];
