
//{{BLOCK(pause_and_about_menus_ss)

//======================================================================
//
//	pause_and_about_menus_ss, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2022-11-08, 17:27:19
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSE_AND_ABOUT_MENUS_SS_H
#define GRIT_PAUSE_AND_ABOUT_MENUS_SS_H

#define pause_and_about_menus_ssTilesLen 32768
extern const unsigned short pause_and_about_menus_ssTiles[16384];

#define pause_and_about_menus_ssPalLen 512
extern const unsigned short pause_and_about_menus_ssPal[256];

#endif // GRIT_PAUSE_AND_ABOUT_MENUS_SS_H

//}}BLOCK(pause_and_about_menus_ss)
