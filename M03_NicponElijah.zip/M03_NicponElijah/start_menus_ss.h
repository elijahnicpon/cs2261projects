
//{{BLOCK(start_menus_ss)

//======================================================================
//
//	start_menus_ss, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2022-11-07, 01:52:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_START_MENUS_SS_H
#define GRIT_START_MENUS_SS_H

#define start_menus_ssTilesLen 32768
extern const unsigned short start_menus_ssTiles[16384];

#define start_menus_ssPalLen 512
extern const unsigned short start_menus_ssPal[256];

#endif // GRIT_START_MENUS_SS_H

//}}BLOCK(start_menus_ss)
