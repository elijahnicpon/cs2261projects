// town_w_ocean_view sound made by wav2c

extern const unsigned int town_w_ocean_view_sampleRate;
extern const unsigned int town_w_ocean_view_length;
extern const signed char town_w_ocean_view_data[];
