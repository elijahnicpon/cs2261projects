// coin sound made by wav2c

extern const unsigned int coin_sampleRate;
extern const unsigned int coin_length;
extern const signed char coin_data[];
