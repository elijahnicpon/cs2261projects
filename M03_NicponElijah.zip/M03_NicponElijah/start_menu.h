void goStartMenu();
void doStartMenu();