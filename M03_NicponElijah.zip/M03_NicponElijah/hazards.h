void initHazards();
void newHazard();
void updateAndDrawHazards();
void updateAndDrawShield();