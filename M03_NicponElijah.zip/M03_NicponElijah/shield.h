// shield sound made by wav2c

extern const unsigned int shield_sampleRate;
extern const unsigned int shield_length;
extern const signed char shield_data[];
