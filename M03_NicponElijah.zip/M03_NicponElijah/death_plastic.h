void goDeathPlastic();
void doDeathPlastic();