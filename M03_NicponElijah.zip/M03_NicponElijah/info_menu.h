void goInfoMenu();
void doInfoMenu();