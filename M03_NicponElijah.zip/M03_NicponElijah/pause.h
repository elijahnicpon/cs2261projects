void goPause();
void doPause();