enum STATE {START, GAME, PAUSE, WIN, LOSE};
#include "start.h"
#include "game.h"
#include "pause.h"
// #include "win.h"
// #include "lose.h"

int state;