void goGame();
void doGame();
void resumeGame();