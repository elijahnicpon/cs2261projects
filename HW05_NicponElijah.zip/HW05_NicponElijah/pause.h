void doPause();
void goPause();