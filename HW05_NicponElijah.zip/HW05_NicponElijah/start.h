void goStart();
void doStart();