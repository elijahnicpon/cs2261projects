void doWin();
void goWin();