void goLose();
void doLose();