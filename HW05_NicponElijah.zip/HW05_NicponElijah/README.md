# Welcome to Elijah's DigDug Submission!
---
## Controls
- →     ~ Player Right
- ←     ~ Player Left
- ↑     ~ Player Up
- ↓     ~ Player Down
- START ~ Play/Pause
- (A)   ~ Fire Air Pump
---
## Notes
- enemies are done by group
- idk there was a lot of question marks in this homework pdf please be nice :)
- Travis and Julia said it doesn't need to be restartable this time,, once we learn malloc I got this tho.