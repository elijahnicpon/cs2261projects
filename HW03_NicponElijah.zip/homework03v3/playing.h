void doPlaying();
void goPlaying();
void resumePlaying();