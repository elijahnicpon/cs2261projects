# Welcome to my Homework 3 ReadMe!
## Elijah Nicpon
---
## Instructions
### Objective
- To win, one must successfully remove all barriers without being hit by one of the red obstacles.
### Basic Controls
- Use the arrow keys (↑,↓,←,→) to move your player.
- During the game, pressing (START) enters pause.
### Keys
- Collect keys by pressing the (A) button while on top of the key.
- When you collect a key, your player assumes the color of the key.
- To drop the key, press (A).
- You can only have one key at a time.
- Remove barriers that are the same color as your player by pressing (B) while pressing agains the barrier.
