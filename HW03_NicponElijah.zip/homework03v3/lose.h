void doLose();
void goLose();