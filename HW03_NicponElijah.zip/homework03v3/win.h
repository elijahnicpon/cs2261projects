void goWin();
void doWin();