
// HW03 Scaffold
// Mode 3 Text-drawing prototypes
void drawChar(int col, int row, char ch, unsigned short color);
void drawString(int col, int row, char *str, unsigned short color);