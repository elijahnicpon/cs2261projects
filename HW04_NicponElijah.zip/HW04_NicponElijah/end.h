void doEnd();
void goEnd(int score);
