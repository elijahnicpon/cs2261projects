// HW04 Scaffold
// Mode 3 Text-drawing prototypes
void drawChar3(int, int, char, unsigned short);
void drawString3(int, int, char *, unsigned short);

// Mode 4 Text-drawing prototypes
void drawChar4(int col, int row, char ch, unsigned char colorIndex);
void drawString4(int col, int row, char *str, unsigned char colorIndex);