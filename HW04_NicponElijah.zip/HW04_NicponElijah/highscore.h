void doHighScore();
void goHighScore();