
//{{BLOCK(pikachu)

//======================================================================
//
//	pikachu, 28x16@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 448 = 960
//
//	Time-stamp: 2022-10-19, 17:41:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PIKACHU_H
#define GRIT_PIKACHU_H

#define pikachuBitmapLen 448
extern const unsigned short pikachuBitmap[224];

#define pikachuPalLen 512
extern const unsigned short pikachuPal[256];

#endif // GRIT_PIKACHU_H

//}}BLOCK(pikachu)
