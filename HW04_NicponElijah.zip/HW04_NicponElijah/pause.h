void goPause(int time);
void doPause();