enum STATE {START, GAME, PAUSE, END, HIGHSCORE};
#include "start.h"
#include "game.h"
#include "pause.h"
#include "end.h"
#include "highscore.h"

int state;
extern int highScore;