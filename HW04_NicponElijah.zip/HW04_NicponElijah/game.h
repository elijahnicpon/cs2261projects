void goGame(int seed);
void resumeGame();
void doGame();

