void goStart();
void doStart();

extern int highScore;