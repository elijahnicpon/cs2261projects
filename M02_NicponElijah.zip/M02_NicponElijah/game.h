void goGame();
void doGame();
void resumeGame();
void newGameRun();

// typedef struct {
//     int x;
//     int prevX;
//     int y;
//     int frame;
//     int numFrames;
//     int height;
//     int width;
//     int entry_OAM;
//     int shieldsLeft;
//     int agility;
//     int energy;
//     int startingEnergy;
    
//     int shieldUpgradeValue;
//     int agilityUpgradeValue;
//     int energyUpgradeValue;

//     int shieldUpgradeCost;
//     int agilityUpgradeCost;
//     int energyUpgradeCost;
// } Player;

//Player player;